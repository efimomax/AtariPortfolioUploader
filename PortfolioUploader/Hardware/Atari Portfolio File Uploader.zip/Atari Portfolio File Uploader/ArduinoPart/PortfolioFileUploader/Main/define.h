
/*************************************/
/* this code is used for arduino Micro
 *  If you change the arduino board, please check the define to adapte the pin 
 */

#ifndef My_Defines
#define My_Defines



typedef enum
{
  VERB_QUIET = 0,
  VERB_ERRORS,
  VERB_COUNTER,
  VERB_FLOWCONTROL
} VERBOSITY;

// this define are used in the Transfolio file.
// only used to upload file
#define PIN_INPUT_CLOCK   9   //pin sub D25 pin 12
#define PIN_INPUT_DATA    10  //pin sub D25 pin 13

#define PIN_OUTPUT_CLOCK  5   //pin sub D25 pin 3
#define PIN_OUTPUT_DATA   4   //pin sub D25 pin 2

#endif
